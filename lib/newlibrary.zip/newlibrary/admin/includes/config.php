<?php 
	$host = "localhost";
	$username="root";
	$password = "";
	$database = "library";
	$connect = mysqli_connect($host,$username,$password,$database);
?>